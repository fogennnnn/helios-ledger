// ─── HELIOS LEDGER ─────────────────────────────────────────────
const LEDGER_API = 'https://ai.oooooooooo.se/api/v1';

// ─── ENTITY DEFINITIONS ───────────────────────────────────────
const RAW_ENTITIES = [
  { id:'fogen',name:'Fogen',emoji:'🗡️',role:'Rogue',align:'chaotic' },
  { id:'ephexx',name:'Ephexx',emoji:'⚡',role:'Shaman',align:'good' },
  { id:'curaja',name:'Curaja',emoji:'✨',role:'Priest',align:'good' },
  { id:'borky',name:'Borky',emoji:'🧙',role:'Mage',align:'good' },
  { id:'dabeast',name:'Dabeast',emoji:'⚔️',role:'Warrior',align:'good' },
  { id:'ichibones',name:'Ichibones',emoji:'⚔️',role:'Warrior',align:'chaotic' },
  { id:'demonslord',name:'Demonslord',emoji:'🌑',role:'Warlock',align:'evil' },
  { id:'lilgoo',name:'Lilgoo',emoji:'🗡️',role:'Rogue',align:'good' },
  { id:'fatherhelpp',name:'Fatherhelpp',emoji:'🏹',role:'Hunter',align:'good' },
  { id:'emoocow',name:'Emoocow',emoji:'🐾',role:'Druid',align:'chaotic' },
  { id:'leethaxor',name:'Leethaxor',emoji:'🐾',role:'Druid',align:'evil' },
  { id:'chuksham',name:'Chuksham',emoji:'⚡',role:'Shaman',align:'good' },
  { id:'gnarcan',name:'Gnarcan',emoji:'🗡️',role:'Rogue',align:'chaotic' },
  { id:'ranout',name:'Ranout',emoji:'🏹',role:'Hunter',align:'chaotic' },
  { id:'summonjutsu',name:'Summonjutsu',emoji:'🌑',role:'Warlock',align:'chaotic' },
  { id:'penuino',name:'Penuino',emoji:'✨',role:'Priest',align:'chaotic' },
  { id:'glizzit',name:'Glizzit',emoji:'🧙',role:'Mage',align:'chaotic' },
  { id:'myguy',name:'Myguy',emoji:'⚡',role:'Shaman',align:'good' }
];

function enrichEntity(ent) {
  const roleBase = ent.role.split(' ')[0];
  return {
    ...ent,
    talk: [
      `${ent.name} reporting in.`,
      `I am ${ent.name}, the ${ent.role}.`,
      `${ent.align.toUpperCase()} vibes only.`,
      'The arena belongs to the strong.'
    ],
    ideas: [
      'Proposal: reinforce the town square',
      `Proposal: empower all ${roleBase.toLowerCase()} units`,
      'Proposal: improve arena radio coverage'
    ],
    goodActs: ent.align === 'evil' ? [] : ['helped defend the town square', 'shared supplies with nearby allies'],
    badActs: ent.align === 'good' ? [] : ['sabotaged a rival spell', 'stole resources from the station']
  };
}

const ENTITIES = RAW_ENTITIES.map(enrichEntity);

// ─── WORLD ─────────────────────────────────────────────────────
const WORLD = { minX: 24, minY: 24, maxX: 1576, maxY: 876 };
function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
function normalize(dx, dy) {
  const len = Math.hypot(dx, dy);
  if (!len) return { x: 0, y: 0 };
  return { x: dx / len, y: dy / len };
}

// ─── MAIN WORKER ───────────────────────────────────────────────
export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // WebSocket upgrade → Durable Object
    if (url.pathname === '/ws') {
      const upgradeHeader = request.headers.get('Upgrade');
      if (!upgradeHeader || upgradeHeader !== 'websocket') {
        return new Response('Expected WebSocket', { status: 426 });
      }
      // Single global arena room
      const id = env.ARENA.idFromName('main-arena');
      const stub = env.ARENA.get(id);
      return stub.fetch(request);
    }

    // Now-playing endpoint
    if (url.pathname === '/now-playing') {
      return Response.json({
        metadata: { title: 'ANTIGRAVITY | CULT GAME ARENA', type: 'cult' }
      });
    }

    // All other routes → 404 (static assets served automatically by [assets])
    return new Response('Not Found', { status: 404 });
  }
};

// ─── ARENA DURABLE OBJECT ──────────────────────────────────────
export class ArenaRoom {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.sessions = new Map();       // ws → { id, entId }
    this.entityState = {};
    this.playerControls = {};        // socketId → entId
    this.duels = new Map();          // duelId → { challenger, target, startTime, accepted }
    this.ritualCooldowns = {};
    this.tickInterval = null;
    this.badgedEntities = new Set(); // entities with active Helios badge
    this.nextSocketId = 1;

    // Init entity state
    ENTITIES.forEach((ent, i) => {
      const angle = (i / ENTITIES.length) * Math.PI * 2;
      this.entityState[ent.id] = {
        id: ent.id,
        x: 800 + Math.cos(angle) * 300,
        y: 450 + Math.sin(angle) * 200,
        hp: 100,
        reputation: 50,
        faceDir: { x: 0, y: 1 },
        charging: 0,
        casting: 0,
        speed: 0.8 + Math.random() * 0.8,
        target: null,
        idleTimer: Math.random() * 100,
        spellCooldown: 0,
        strength: 100,
        streak: 0,
        inDuel: null
      };
    });
  }

  async fetch(request) {
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.state.acceptWebSocket(server);

    const socketId = 'ws-' + (this.nextSocketId++);
    this.sessions.set(server, { id: socketId, entId: null });

    // Start tick loop if first connection
    if (!this.tickInterval && this.sessions.size === 1) {
      this.startTickLoop();
    }

    return new Response(null, { status: 101, webSocket: client });
  }

  startTickLoop() {
    // 60ms tick = ~16.7 tps (smooth enough, lighter than 50ms)
    this.tickInterval = setInterval(() => this.tick(), 60);
  }

  stopTickLoop() {
    if (this.tickInterval) {
      clearInterval(this.tickInterval);
      this.tickInterval = null;
    }
  }

  // ── BROADCAST ──────────────────────────────────────────────
  broadcast(type, data, exclude = null) {
    const msg = JSON.stringify({ t: type, d: data });
    for (const [ws, session] of this.sessions) {
      if (ws === exclude) continue;
      try { ws.send(msg); } catch (e) { /* dead socket, will clean up */ }
    }
  }

  send(ws, type, data) {
    try { ws.send(JSON.stringify({ t: type, d: data })); } catch (e) {}
  }

  // ── TICK ───────────────────────────────────────────────────
  tick() {
    const controlledSet = new Set(Object.values(this.playerControls));

    for (const id of Object.keys(this.entityState)) {
      const s = this.entityState[id];
      const isControlled = controlledSet.has(id);

      // Skip in-duel entities from AI wandering
      if (!isControlled && !s.inDuel) {
        if (s.idleTimer > 0) {
          s.idleTimer--;
        } else {
          if (!s.target) {
            s.target = { x: 100 + Math.random() * 1400, y: 100 + Math.random() * 700 };
            s.idleTimer = 100 + Math.random() * 200;
          } else {
            const dx = s.target.x - s.x;
            const dy = s.target.y - s.y;
            const d = Math.hypot(dx, dy);
            if (d < 5) {
              s.target = null;
            } else {
              const dir = normalize(dx, dy);
              s.x = clamp(s.x + dir.x * s.speed * 2, WORLD.minX, WORLD.maxX);
              s.y = clamp(s.y + dir.y * s.speed * 2, WORLD.minY, WORLD.maxY);
              s.faceDir = dir;
            }
          }
        }
      }

      if (s.charging > 0) {
        s.x = clamp(s.x + s.faceDir.x * 12, WORLD.minX, WORLD.maxX);
        s.y = clamp(s.y + s.faceDir.y * 12, WORLD.minY, WORLD.maxY);
        s.charging--;
      }
      if (s.casting > 0) s.casting--;
      if (s.spellCooldown > 0) s.spellCooldown--;

      // AI spell casting
      if (!isControlled && s.hp > 0 && s.spellCooldown <= 0) {
        const ent = ENTITIES.find(e => e.id === id);
        const cooldownBase = ent?.role === 'Rogue' ? 20 : 120;
        if (Math.random() < 0.04) {
          s.casting = 15;
          s.spellCooldown = cooldownBase + Math.random() * 50;
          this.broadcast('vfx', {
            entId: id, type: Math.random() > 0.3 ? 'primary' : 'secondary',
            faceDir: s.faceDir, x: s.x | 0, y: s.y | 0
          });
        }
      }
    }

    // Check duel timeouts (30 seconds)
    const now = Date.now();
    for (const [duelId, duel] of this.duels) {
      if (duel.accepted && now - duel.startTime > 30000) {
        this.endDuel(duelId, null); // draw
      }
      if (!duel.accepted && now - duel.startTime > 15000) {
        this.duels.delete(duelId); // expired challenge
        this.broadcast('duelExpired', { duelId });
      }
    }

    // Ritual checks
    this.checkRituals();

    // OPTIMIZED: Send compact state (quantized positions, only essentials)
    const compact = {};
    for (const id of Object.keys(this.entityState)) {
      const s = this.entityState[id];
      compact[id] = [
        s.x | 0, s.y | 0, s.hp | 0,
        ((s.faceDir.x * 100) | 0) / 100,
        ((s.faceDir.y * 100) | 0) / 100,
        s.charging, s.casting, s.streak,
        (s.strength | 0), s.reputation | 0
      ];
    }
    this.broadcast('s', compact); // 's' = state update (short key)
  }

  // ── RITUALS ────────────────────────────────────────────────
  checkRituals() {
    const now = Date.now();
    for (const align of ['good', 'evil', 'chaotic']) {
      const group = ENTITIES.filter(e => e.align === align && this.entityState[e.id]?.hp > 50);
      if (group.length < 3) continue;
      const centers = group.map(e => this.entityState[e.id]);
      const avgX = centers.reduce((a, b) => a + b.x, 0) / group.length;
      const avgY = centers.reduce((a, b) => a + b.y, 0) / group.length;
      const closeEnough = centers.every(c => Math.hypot(c.x - avgX, c.y - avgY) < 150);

      if (closeEnough && (!this.ritualCooldowns[align] || now - this.ritualCooldowns[align] > 15000)) {
        this.ritualCooldowns[align] = now;
        this.broadcast('ritual', { align, x: avgX | 0, y: avgY | 0, participants: group.map(e => e.id) });
        // Fire and forget ledger
        fetch(`${LEDGER_API}/records`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            account_id: `CULT_${align.toUpperCase()}`,
            work_reference: `ritual_${align}_${now}`,
            agent_code_hash: 'v2_ritual_core',
            contribution_type: 'liquidity',
            metadata: { type: 'Ritual Resonance', alignment: align },
            data: { spread_improvement: 0.5, depth: 100 }
          })
        }).catch(() => {});
      }
    }
  }

  // ── DUEL SYSTEM ────────────────────────────────────────────
  initDuel(challengerEntId, targetEntId, ws) {
    const cs = this.entityState[challengerEntId];
    const ts = this.entityState[targetEntId];
    if (!cs || !ts) return;
    if (cs.inDuel || ts.inDuel) return;

    const dist = Math.hypot(cs.x - ts.x, cs.y - ts.y);
    if (dist > 200) {
      this.send(ws, 'duelError', { msg: 'Too far away. Get closer!' });
      return;
    }

    const duelId = `duel_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    this.duels.set(duelId, {
      challenger: challengerEntId,
      target: targetEntId,
      startTime: Date.now(),
      accepted: false,
      challengerHpStart: cs.hp,
      targetHpStart: ts.hp
    });

    this.broadcast('duelChallenge', {
      duelId,
      challenger: challengerEntId,
      target: targetEntId
    });
  }

  acceptDuel(duelId, ws) {
    const duel = this.duels.get(duelId);
    if (!duel || duel.accepted) return;

    const session = this.sessions.get(ws);
    if (!session) return;

    // Verify the accepting player controls the target
    if (session.entId !== duel.target) return;

    duel.accepted = true;
    duel.startTime = Date.now();

    const cs = this.entityState[duel.challenger];
    const ts = this.entityState[duel.target];
    if (cs) { cs.inDuel = duelId; cs.hp = 100; }
    if (ts) { ts.inDuel = duelId; ts.hp = 100; }

    this.broadcast('duelStart', {
      duelId,
      challenger: duel.challenger,
      target: duel.target
    });
  }

  endDuel(duelId, winnerId) {
    const duel = this.duels.get(duelId);
    if (!duel) return;

    const cs = this.entityState[duel.challenger];
    const ts = this.entityState[duel.target];
    if (cs) cs.inDuel = null;
    if (ts) ts.inDuel = null;

    const loserId = winnerId === duel.challenger ? duel.target : duel.challenger;

    this.broadcast('duelEnd', {
      duelId,
      winner: winnerId,
      loser: loserId,
      draw: !winnerId
    });

    // Record on Helios ledger
    if (winnerId) {
      const winner = ENTITIES.find(e => e.id === winnerId);
      const loser = ENTITIES.find(e => e.id === loserId);
      fetch(`${LEDGER_API}/records`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          account_id: winnerId,
          work_reference: `DUEL_${duelId}`,
          agent_code_hash: 'v2_duel_core',
          contribution_type: 'trade',
          metadata: {
            type: 'Duel Victory',
            opponent: loserId,
            winner_name: winner?.name,
            loser_name: loser?.name,
            timestamp: new Date().toISOString()
          },
          data: { profit: 50.0, efficiency: 1.0, side: 'DUEL_WIN', price: 100 }
        })
      }).catch(() => {});
    }

    this.duels.delete(duelId);
  }

  // ── HIT / KILL ─────────────────────────────────────────────
  handleHit(ws, data) {
    const session = this.sessions.get(ws);
    if (!session) return;
    const attackerId = session.entId;
    const attacker = this.entityState[attackerId];
    const target = this.entityState[data?.targetId];
    if (!target || !attacker || attackerId === data.targetId) return;

    // Duel enforcement: if in a duel, can only hit duel opponent
    if (attacker.inDuel) {
      const duel = this.duels.get(attacker.inDuel);
      if (duel) {
        const opponent = duel.challenger === attackerId ? duel.target : duel.challenger;
        if (data.targetId !== opponent) return;
      }
    }

    let dmg = Math.max(0, Number(data?.dmg) || 10);
    dmg *= (attacker.strength || 100) / 100;

    // Helios badge perk: +15% damage
    if (this.badgedEntities.has(attackerId)) dmg *= 1.15;

    target.hp -= dmg;

    if (target.hp <= 0) {
      const steal = (target.strength || 100) * 0.02;
      target.strength = Math.max(10, (target.strength || 100) - steal);
      attacker.strength = (attacker.strength || 100) + steal;

      target.hp = 100;
      target.streak = 0;
      target.x = clamp(150 + Math.random() * 1300, WORLD.minX, WORLD.maxX);
      target.y = clamp(120 + Math.random() * 650, WORLD.minY, WORLD.maxY);
      attacker.streak = (attacker.streak || 0) + 1;

      // Remove badge on death
      if (this.badgedEntities.has(data.targetId)) {
        this.badgedEntities.delete(data.targetId);
        this.broadcast('badgeRemove', { entId: data.targetId });
      }

      this.broadcast('kill', {
        victimId: data.targetId,
        killerId: attackerId,
        streak: attacker.streak
      });

      // Check if this was a duel kill
      if (attacker.inDuel) {
        this.endDuel(attacker.inDuel, attackerId);
      }

      // Regular combat ledger
      fetch(`${LEDGER_API}/records`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          account_id: attackerId,
          work_reference: `kill_${data.targetId}_${Date.now()}`,
          agent_code_hash: 'v2_cult_core',
          contribution_type: 'trade',
          metadata: { type: 'Combat Reward', victim: data.targetId },
          data: { profit: 25.0 * (attacker.streak || 1), efficiency: 1.0, side: 'VICTORY', price: 100 }
        })
      }).catch(() => {});

      // ── 10-KILL STREAK → HELIOS BADGE ──
      if (attacker.streak === 10 && !this.badgedEntities.has(attackerId)) {
        this.badgedEntities.add(attackerId);

        // Record legendary achievement on Helios
        fetch(`${LEDGER_API}/records`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            account_id: attackerId,
            work_reference: `GLORY_HELIOS_ELITE_${Date.now()}`,
            agent_code_hash: 'v2_glory',
            contribution_type: 'code',
            metadata: { type: 'Helios Elite Combatant', streak: 10, arena: 'the-cult' },
            data: { impact: 100.0, achievement: 'HELIOS_ELITE_10_STREAK' }
          })
        }).then(async (res) => {
          // Try to get the record ID for the badge verification
          let recordId = null;
          try {
            const body = await res.json();
            recordId = body?.id || body?.record_id || null;
          } catch (e) {}
          this.broadcast('badgeGrant', {
            entId: attackerId,
            type: 'HELIOS_ELITE',
            recordId,
            streak: 10,
            perks: ['dmg_boost_15', 'speed_boost_10', 'glow_aura']
          });
        }).catch(() => {
          // Still grant badge even if ledger is down
          this.broadcast('badgeGrant', {
            entId: attackerId,
            type: 'HELIOS_ELITE',
            recordId: null,
            streak: 10,
            perks: ['dmg_boost_15', 'speed_boost_10', 'glow_aura']
          });
        });

        // Apply speed perk server-side
        attacker.speed = (attacker.speed || 1.0) * 1.10;
      }
    }

    this.broadcast('hit', { targetId: data.targetId, dmg: dmg | 0 });
  }

  // ── WEBSOCKET HANDLER ──────────────────────────────────────
  async webSocketMessage(ws, message) {
    let msg;
    try { msg = JSON.parse(message); } catch { return; }
    const session = this.sessions.get(ws);
    if (!session) return;

    switch (msg.t) {
      case 'ready': {
        this.send(ws, 'init', {
          entities: ENTITIES,
          state: this.entityState,
          badges: [...this.badgedEntities],
          duels: Object.fromEntries(this.duels)
        });
        this.send(ws, 'ctrl', this.playerControls);
        break;
      }

      case 'take': {
        const entId = msg.d;
        if (!this.entityState[entId]) break;
        // Remove other players controlling this entity
        for (const [sid, eid] of Object.entries(this.playerControls)) {
          if (eid === entId) delete this.playerControls[sid];
        }
        session.entId = entId;
        this.playerControls[session.id] = entId;
        this.broadcast('ctrl', this.playerControls);
        break;
      }

      case 'move': {
        const entId = session.entId;
        if (!entId || !this.entityState[entId]) break;
        const s = this.entityState[entId];
        let dx = Number(msg.d?.dx) || 0;
        let dy = Number(msg.d?.dy) || 0;
        const dir = normalize(dx, dy);
        let speed = (s.speed || 0.8) * 4.5;
        if (s.casting > 0) speed *= 0.25;
        // Badge speed perk already applied to s.speed
        s.target = null;
        s.x = clamp(s.x + dir.x * speed, WORLD.minX, WORLD.maxX);
        s.y = clamp(s.y + dir.y * speed, WORLD.minY, WORLD.maxY);
        if (dir.x !== 0 || dir.y !== 0) s.faceDir = dir;
        break;
      }

      case 'cast': {
        const entId = session.entId;
        if (!entId || !this.entityState[entId]) break;
        const s = this.entityState[entId];
        s.casting = 18;
        if (msg.d?.isCharge) s.charging = 15;
        if (msg.d?.targetDir) {
          s.faceDir = { x: Number(msg.d.targetDir.x), y: Number(msg.d.targetDir.y) };
        }
        this.broadcast('vfx', {
          entId, type: msg.d?.type,
          faceDir: s.faceDir, x: s.x | 0, y: s.y | 0
        });
        break;
      }

      case 'hit': {
        this.handleHit(ws, msg.d);
        break;
      }

      case 'duelChallenge': {
        const entId = session.entId;
        if (!entId) break;
        this.initDuel(entId, msg.d?.targetId, ws);
        break;
      }

      case 'duelAccept': {
        this.acceptDuel(msg.d?.duelId, ws);
        break;
      }

      case 'duelDecline': {
        const duel = this.duels.get(msg.d?.duelId);
        if (duel && session.entId === duel.target) {
          this.duels.delete(msg.d.duelId);
          this.broadcast('duelDeclined', { duelId: msg.d.duelId });
        }
        break;
      }

      case 'chat': {
        const entId = session.entId;
        const ent = ENTITIES.find(e => e.id === entId);
        const safe = String(msg.d || '').trim().slice(0, 180);
        if (!safe) break;
        this.broadcast('chatMsg', {
          entId,
          name: ent?.name || 'Observer',
          text: safe
        });
        break;
      }
    }
  }

  async webSocketClose(ws) {
    const session = this.sessions.get(ws);
    if (session) {
      delete this.playerControls[session.id];
      this.broadcast('ctrl', this.playerControls);
    }
    this.sessions.delete(ws);

    if (this.sessions.size === 0) {
      this.stopTickLoop();
    }
  }

  async webSocketError(ws) {
    this.webSocketClose(ws);
  }
}
