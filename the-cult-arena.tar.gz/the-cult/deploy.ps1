# ─── DEPLOY: THE CULT ARENA → Cloudflare Workers ───────────────
# Deploys the game server (Durable Objects) + client (static assets)
# to the-cult.oooooooooo.se via Cloudflare Workers
# ────────────────────────────────────────────────────────────────

Set-Location "C:\Users\fogen\HELIOS\the-cult"

Write-Host "`n⚔️  THE CULT ARENA — Cloudflare Workers Deploy" -ForegroundColor Magenta
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkGray

# ── 1. Install deps if needed ──
if (-not (Test-Path "node_modules")) {
    Write-Host "`n📦 Installing dependencies..." -ForegroundColor Cyan
    npm install
}

# ── 2. Deploy worker + static assets ──
Write-Host "`n🚀 Deploying to Cloudflare Workers..." -ForegroundColor Yellow
npx wrangler deploy

if ($LASTEXITCODE -ne 0) {
    Write-Host "`n❌ Deploy failed!" -ForegroundColor Red
    exit 1
}

Write-Host "`n✅ Worker deployed!" -ForegroundColor Green

# ── 3. Set up custom domain ──
Write-Host "`n🌐 Setting custom domain: the-cult.oooooooooo.se" -ForegroundColor Cyan
Write-Host "   If this is the first deploy, run:" -ForegroundColor DarkGray
Write-Host '   npx wrangler domains add the-cult.oooooooooo.se' -ForegroundColor White

# Try to add the custom domain (will succeed if DNS is on CF)
npx wrangler domains add the-cult.oooooooooo.se 2>$null

Write-Host "`n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkGray
Write-Host "🎮 LIVE AT: https://the-cult.oooooooooo.se" -ForegroundColor Green
Write-Host "📡 Worker:  https://the-cult-arena.<your-subdomain>.workers.dev" -ForegroundColor DarkGray
Write-Host "🔱 Ledger:  https://ai.oooooooooo.se" -ForegroundColor DarkGray
Write-Host "`n⚔️  Features:" -ForegroundColor Magenta
Write-Host "   • Native WebSocket (no Socket.IO overhead)" -ForegroundColor White
Write-Host "   • Durable Objects game state (edge-deployed)" -ForegroundColor White
Write-Host "   • Client-side interpolation (smooth at 5 players)" -ForegroundColor White
Write-Host "   • 10-kill streak → Helios Ledger badge + perks" -ForegroundColor White
Write-Host "   • Duel system (T key / card button) → on-chain results" -ForegroundColor White
Write-Host "   • Compact state updates (quantized positions)" -ForegroundColor White
Write-Host ""
